package ed.example.estado;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;

public class MainActivity extends AppCompatActivity {
private Button miboton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this,"se ejecuto el estado onCREATE",Toast.LENGTH_SHORT).show();
        miboton=findViewById(R.id.button2);
        miboton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),MainActivity2.class);
                startActivity(i);
                                    }
                                    });
           }
    @Override
    protected void onPause(){
     super.onPause();
        Toast.makeText(this,"se ejecuto el estado onPAUSE",Toast.LENGTH_SHORT).show();

    }
    @Override
    protected void onRestart(){
        super.onRestart();
        Toast.makeText(this,"se ejecuto el estado onRESTART",Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onResume(){
        super.onResume();;
        Toast.makeText(this,"se ejecuto el estado onRESUME",Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onStart(){
        super.onStart();
        Toast.makeText(this,"se ejecuto el estado onSTART",Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onStop(){
        super.onStop();
        Toast.makeText(this,"se ejecuto el estado onStopT",Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Toast.makeText(this,"se ejecuto el estado onDESTRUIR",Toast.LENGTH_SHORT).show();
    }
}